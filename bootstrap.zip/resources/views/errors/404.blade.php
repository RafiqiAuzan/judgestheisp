<x-layouts.error title="Not Found" code="404" message="Halaman tidak ditemukan" />
