<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.test','data' => ['title' => 'Aplikasi Tes Psikologi Terbaik']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.test'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aplikasi Tes Psikologi Terbaik']); ?>
    <section class="">
        <div class="space-y-8">
            <div class="flex flex-col gap-8 lg:flex-row">
                <div class="w-full h-fit p-8 space-y-4 rounded-3xl bg-light-100">
                    <div class="py-3">
                        <a class="text-3xl text-base-800 font-bold font-display">Informed Consent</a>
                        <div class="pt-3 text-base-800">
                            <p class="text-justify">Dengan ini, saya menyatakan bahwa saya berkomitmen untuk:</p>
                            <ul class="text-justify list-disc list-inside">
                                <li>Mengerjakan tes ini secara <b>sukarela</b></li>
                                <li>Menjaga <b>kerahasiaan</b> tes, tidak menyebar-luaskan tes dalam bentuk apa pun</li>
                                <li>Memahami bahwa tes ini sedang dalam pengembangan sehingga laporan hasil <b>tidak diberikan secara individual</b></li>
                                <li>Memahami bahwa data saya <b>akan dijaga kerahasiaannya</b> dan hanya akan digunakan untuk kepentingan pengembangan tes</li>
                            </ul>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <input type="checkbox" value="" class="w-[24px] h-[24px] text-base-400 rounded-3xl">
                        <label class="ml-2 text-sm font-normal text-base-800">Setuju</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex flex-row justify-end items-center mt-32">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.atoms.button','data' => ['class' => 'lg:w-auto w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('atoms.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'lg:w-auto w-full']); ?>Selanjutnya <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\Lomba\resources\views/pages/test/informed-consent.blade.php ENDPATH**/ ?>