<html>
	<head>
		<title>My first html page</title>
	</head>
    <style>
    </style>
	<body>
        <div class="row">
            <div class="col-md-12 text-center">
              <h1>Make Google charts responsive</h1>
              <p>Full blog post details <a href="http://flopreynat.com/blog/make-google-charts-responsive.html">on my blog</a></p>
            </div>
            <div class="col-md-4 col-md-offset-4">
              <hr />
            </div>
            <div class="clearfix"></div>
            <div class="col-md-6">
              <div id="chart_div1" class="chart"></div>
            </div>
            <div class="col-md-6">
              <div id="chart_div2" class="chart"></div>
            </div>
          </div>
	</body>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script>
        
        google.load("visualization", "1", {packages:["corechart"]});
        google.setOnLoadCallback(drawChart1);
        function drawChart1() {
          var data = google.visualization.arrayToDataTable([
            ['Year', 'Sales', 'Expenses'],
            ['2004',  1000,      400],
            ['2005',  1170,      460],
            ['2006',  660,       1120],
            ['2007',  1030,      540]
          ]);
        
          var options = {
         };
        
        var chart = new google.visualization.ColumnChart(document.getElementById('chart_div1'));
          chart.draw(data, options);
        }</script>
</html><?php /**PATH C:\laragon\www\judgestheisp\resources\views/pages/test.blade.php ENDPATH**/ ?>