<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'size' => 'default',
    'status' => 'solid',
    'tag' => empty($href) ? 'button' : 'a',
    'class' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'size' => 'default',
    'status' => 'solid',
    'tag' => empty($href) ? 'button' : 'a',
    'class' => '',
]); ?>
<?php foreach (array_filter(([
    'size' => 'default',
    'status' => 'solid',
    'tag' => empty($href) ? 'button' : 'a',
    'class' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<<?php echo e($tag); ?> <?php echo e($attributes); ?> class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    ' rounded-full font-bold transition',

    'flex flex-row justify-center items-center' => $tag == 'button',
    'inline-block' => $tag == 'a',

    'text-base leading-6 py-4 px-16 gap-4' => $size == 'lg',
    'text-sm leading-5 py-[14px] px-14 gap-[14px]' => $size == 'default',
    'text-xs leading-4 py-[9px] px-9 gap-[9px]' => $size == 'sm',
    'text-xs leading-4 py-[6px] px-6 gap-[6px]' => $size == 'xs',

    'text-base leading-6 p-4 gap-4' => $size == 'icon-lg',
    'text-sm leading-5 p-[14px] gap-[14px]' => $size == 'icon-default',
    'text-xs leading-4 p-[9px] gap-[9px]' => $size == 'icon-sm',
    'text-xs leading-4 p-[6px] gap-[6px]' => $size == 'icon-xs',

    'border border-solid bg-[#41B853] text-base-100 hover:bg-[#369144]' =>
        $status == 'solid',
    'border border-solid bg-light-100 border-primary-500 text-primary-500 hover:bg-primary-500 hover:bg-opacity-10' =>
        $status == 'outline',
    'text-primary-500 !p-0 !gap-0' => $status == 'transparent',
    'border border-solid bg-light-300 border-light-200 text-base-500' =>
        $status == 'disabled',

    $class,
]) ?>" <?php if($status == 'disabled'): echo 'disabled'; endif; ?>>
    <?php echo e($slot); ?>

    </<?php echo e($tag); ?>>
<?php /**PATH C:\laragon\www\Lomba\resources\views/components/atoms/button.blade.php ENDPATH**/ ?>