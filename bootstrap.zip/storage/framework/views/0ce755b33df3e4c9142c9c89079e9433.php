<footer class=" bg-[#cccccc] ">
    <div class="container mx-auto">
        <div class="w-full p-3 text-sm lg:text-sm md:text-xl text-center text-[#41B853] font-display">
            <p class="">Copyright © 2023 Judges the ISP by Rafiqi Auzan | Politeknik Negeri Jakarta</p>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\judgestheisp\resources\views/components/atoms/navs/homefooter.blade.php ENDPATH**/ ?>