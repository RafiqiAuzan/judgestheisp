<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.base','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div
        class="relative flex items-top justify-center min-h-screen bg-[#EDEDED] sm:items-center sm:pt-0">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="flex mb-2 items-center justify-center pt-8 sm:pt-0">
                <div class="px-4 text-2xl text-base-600 border-r border-base-600 tracking-wider">
                    <?php echo e($code); ?>

                </div>

                <div class="ml-4 text-2xl text-base-600 uppercase tracking-wider">
                    <?php echo e($title); ?>

                </div>
            </div>
            <p class="text-center font-light text-base-600 py-2 text-lg"><?php echo e($message); ?>

                <br>ke <a class="text-[#60D072]" href="<?php echo e(url('/')); ?>">Halaman
                    Utama</a>
            </p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\judgestheisp\resources\views/components/layouts/error.blade.php ENDPATH**/ ?>