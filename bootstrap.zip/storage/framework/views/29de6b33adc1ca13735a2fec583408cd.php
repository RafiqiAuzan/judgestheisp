<navbar class="fixed z-20 w-full bg-light-100" x-cloak x-data="{ navmenu: false }">
    <div class="container mx-auto gap-[32px] px-2 lg:flex lg:items-center lg:justify-between">
        <div class="flex justify-between my-4">
            
            <div class="mx-6 hidden lg:block">
                <img src="<?php echo e(asset('img/global/mainlogo.webp')); ?>" alt="Logo Pilih Jurusan">
            </div>
            <div class="mx-6 lg:hidden">
                    <i class="fas fa-arrow-left"></i>
            </div>
            
            <div class="flex">
                <span class="lg:hidden" @click="navmenu = ! navmenu">
                    <i class="fas fa-ellipsis-vertical"></i>
                </span>
            </div>
        </div>
        
        <div :class="{ 'hidden lg:block': !navmenu }">
            <div class="absolute py-4 bg-light-100 rounded-lg max-w-[150px] w-full right-7 top-full
        lg:static lg:max-w-full lg:shadow-none lg:rounded-none">
                <div class=" lg:items-center">
                    <ul class="lg:flex ">
                        <li class="flex py-2 mx-2">
                            <a class="rounded-full font-semibold text-base py-[6px] px-[18px] w-[82px] h-9
                            border border-solid bg-light-500 text-light-100">00:08</a>
                        </li>
                        <li><a class="flex py-3 mx-2 "><i class="fas fa-ellipsis-vertical w-6 h-6"></i></a></li> 
                    </ul>
                </div>
            </div>
         
        </div>
    </div>
</navbar><?php /**PATH C:\laragon\www\Lomba\resources\views/components/atoms/navs/testnav.blade.php ENDPATH**/ ?>