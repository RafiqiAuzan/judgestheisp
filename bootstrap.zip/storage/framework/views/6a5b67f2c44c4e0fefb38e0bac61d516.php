<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="./assets/style/style.css">
    <title>Hogwarts School</title>
</head>
<body>
    <header>
        <nav>
			<div>
				<ul>
					<li><a href="#Gryffindor">Gryffindor</a></li>
					<li><a href="#Ravenclaw">Ravenclaw</a></li>
                    <li><a href="#Hufflepuff">Hufflepuff</a></li>
                    <li><a href="#Slytherin">Slytherin</a></li>
				</ul>
			</div>
		</nav>
        
        <div class="bg-img"></div>
			<h1 class="bg-text">Hogwarts School</h1>
    </header>

    <main>
        <div class="content">
            <div id="Gryffindor"></div>
            <article class="card">
				<h2>Gryffindor</h2>
                <div class="slideshow-container">

                    <div class="mySlides-1">
                      <img src="./assets/img/gryffindor2.jpg" id="imageSlide">
                    </div>
                    
                    <div class="mySlides-1">
                      <img src="./assets/img/gryffindor1.png" id="imageSlide-1">
                    </div>
                    
                    <div class="mySlides-1">
                      <img src="./assets/img/gryffindor3.jpg" id="imageSlide">
                    </div>
                    
                </div>
                    <br>
                    
                    <div style="text-align: center;">
                      <span class="dot-1"></span> 
                      <span class="dot-1"></span> 
                      <span class="dot-1"></span>
                    </div>
                <section>
                    <p>Asrama Gryffindor memiliki lambang atau identitas seekor binatang yaitu singa. Kemudian warna merah dan emas adalah warna kebanggaan Gryffindor. Nama itu diambil dari salah satu pendiri sekolah tersebut, Godric Gryffindor. Ia adalah salah satu penyihir terbesar di masanya. Murid-murid yang tinggal di asrama Gryffindor digambarkan sebagai orang-orang yang gagah berani, bersifat ksatria, dan tidak mengenal takut, meskipun terkadang sampai ke titik agresivitas dan kecerobohan.</p>
                </section>
                <section>
                <div id="Ravenclaw"></div> 
                <p>Nilai Asrama Gryffindor : </p>
                <ul>
                    <li>Keberanian</li>
                    <li>Kesetiaan</li>
                    <li>Tekad Kuat</li>
                    <li>Kepahlawanan</li>
                </ul> 
                </section>
                 		
				<h2>Ravenclaw</h2>
                <div class="slideshow-container">

                    <div class="mySlides-2">
                      <img src="./assets/img/ravenclaw1.jpg" id="imageSlide">
                    </div>
                    
                    <div class="mySlides-2">
                      <img src="./assets/img/ravenclaw1.webp" id="imageSlide-1">
                    </div>
                    
                    <div class="mySlides-2">
                      <img src="./assets/img/ravenclaw2.jpg" id="imageSlide-1">
                    </div>
                    
                </div>
                    <br>
                    
                    <div style="text-align: center;">
                      <span class="dot-2"></span> 
                      <span class="dot-2"></span> 
                      <span class="dot-2"></span>
                    </div>  
                <section>
                    <p>Asrama Ravenclaw memiliki lambang atau identitas seekor binatang yaitu elang. Kemudian warna biru dan abu-abu adalah warna kebanggaan Ravenclaw. Ravenclaw berhubungan erat dengan elemen udara. Pendiri asramanya bernama Rowena Ravenclaw. Menilai tinggi kecerdasan, kreativitas, akal, kebijaksanaan, dan individualitas. "Kepintaran tak terhingga merupakan harta manusia yang paling berharga" adalah kutipan yang sering diulang oleh Ravenclaw.</p>
                </section>
                <section>
                <div id="Hufflepuff"></div>      
                   <p>Nilai Asrama Ravenclaw : </p>
                <ul>
                    <li>Kecedasan</li>
                    <li>Kreativitas</li>
                    <li>Rajin Belajar</li>
                    <li>Kecantikan / Ketampanan</li>
                </ul>
                </section>
   
                <h2>Hufflepuff</h2>
                <div class="slideshow-container">

                    <div class="mySlides-3">
                      <img src="./assets/img/hufflepuff.jpg" id="imageSlide-1">
                    </div>
                    
                    <div class="mySlides-3">
                      <img src="./assets/img/hufflepuff1.jpg" id="imageSlide-1">
                    </div>
                    
                    <div class="mySlides-3">
                      <img src="./assets/img/hufflepuff3.jpg" id="imageSlide-1">
                    </div>
                    
                </div>
                    <br>
                    
                    <div style="text-align: center;">
                      <span class="dot-3"></span> 
                      <span class="dot-3"></span> 
                      <span class="dot-3"></span>
                    </div>
                <section>
                    <p>Asrama Hufflepuff memiliki lambang atau identitas seekor binatang yaitu Luak. Kemudian warna kuning dan hitam adalah warna kebanggaan Hufflepuff. Hufflepuff memiliki hubungan dengan elemen bumi. Pendiri asramanya bernama Helga Hufflepuff. Ruang rekreasi Hufflepuff diisi dengan hiasan kuning dan kursi-kursi empuk berlengan dan memiliki terowongan bawah tanah yang mengarah ke asrama, yang semuanya memiliki pintu bulat sempurna, seperti penutup drum (mirip seperti sarang luak).</p>
                </section>
                <section>
                <div id="Slytherin"></div>
                   <p>Nilai Asrama Hufflepuff : </p>
                <ul>
                    <li>Kerja Keras</li>
                    <li>Toleransi</li>
                    <li>Loyalitas</li>
                    <li>Keadilan</li>
                </ul>
                </section>
         
                <h2>Slytherin</h2>
                <div class="slideshow-container">

                    <div class="mySlides-4">
                      <img src="./assets/img/slytherin.jpg" id="imageSlide">
                    </div>
                    
                    <div class="mySlides-4">
                      <img src="./assets/img/slytherin1.jpg" id="imageSlide-1">
                    </div>
                    
                    <div class="mySlides-4">
                      <img src="./assets/img/slytherin2.jpg" id="imageSlide">
                    </div>
                    
                </div>
                    <br>
                    
                    <div style="text-align: center;">
                      <span class="dot-4"></span> 
                      <span class="dot-4"></span> 
                      <span class="dot-4"></span>
                    </div>
                <section>
                    <p>Asrama Slytherin memiliki lambang atau identitas seekor binatang yaitu ular. Kemudian warna hijau dan perak adalah warna kebanggaan Slytherin. Yang paling penting adalah mereka memiliki darah penyihir murni. Pendiri asramanya bernama Salazar Slytherin. Ruang rekreasi asrama ini juga terletak di bawah tanah, Ruang bawah tanah Slytherin terletak di bawah danau sehingga memberikan ruangannya semburat cahaya kehijauan, ruangan ini juga dilengkapi dengan lampu-lampu hijau dan kursi-kursi berukir.</p>
                </section>
                <section>
                   <p>Nilai Asrama Slytherin : </p>
                <ul>
                    <li>Ambisi</li>
                    <li>Idealis</li>
                    <li>Kepemimpinan</li>
                    <li>Kecerdikan</li>
                </ul>
                </section>
            </article>
        </div>

        <aside class="aside">
			<article class="profile card">
				<header>
					<h2>BIODATA</h2>
					<figure>
						<img src="./assets/img/profile.jpg">
						<figcaption id="nama">Rafiqi Auzan</figcaption>
					</figure>
				</header>
				
				<section>
					<table class="info">
						<tr>
							<th>Umur</th>
							<td> : 20 Tahun</td>
						</tr>
						<tr>
							<th>Jurusan</th>
							<td> : Teknik Informatika</td>
						</tr>
						<tr>
							<th>Kampus</th>
							<td>  : Politeknik Negeri Jakarta</td>
						</tr>
						<tr>
							<th>Angkatan</th>
							<td> : 2019</td>
						</tr>
					</table>
				</section>
			</article>
		</aside>
    </main>

    <footer>
        <p class="bawah">Copyright &copy; Hogwarts School 2022 by Rafiqi Auzan</p>
	</footer>

    <script src="./assets/script/script.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\Lomba\resources\views/welcome.blade.php ENDPATH**/ ?>